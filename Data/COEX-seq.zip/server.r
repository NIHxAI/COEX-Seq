library(shiny)
#library(ggplot2)

countToTpm <- function(counts, effLen)
{
  rate <- log(counts) - log(effLen)
  denom <- log(sum(exp(rate)))
  exp(rate - denom + log(1e6))
}

countToFpkm <- function(counts, effLen)
{
  N <- sum(counts)
  exp( log(counts) + log(1e9) - log(effLen) - log(N) )
}

fpkmToTpm <- function(fpkm)
{
  exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}

countToEffCounts <- function(counts, len, effLen)
{
  counts * (len / effLen)
}

TpmToCount <- function(Tpm, effLen)
{
  rate <- log(counts) - log(effLen)
  denom <- log(sum(exp(rate)))
  
  exp(rate - denom + log(1e6))
}

TmpTofpkm <- function(fpkm)
{
  exp(log(fpkm) - log(sum(fpkm)) + log(1e6))
}

FpkmToCount <- function(counts, effLen)
{
  N <- sum(counts)
  exp( log(counts) + log(1e9) - log(effLen) - log(N) )
}


shinyServer(function(input, output) {
  
 
   datasetInput <- reactive({
    
    inFile <- input$file1
    #print(input)
    #print(input$header)
    print(input$sep)
    print(input$file1$name)

    if (is.null(inFile))
      return(NULL)
    
    RawInput <- read.table(inFile$name, header=input$header, sep=input$sep)

    Symbol <- read.table("GeneSymbol_length.txt",sep="\t",header=T)
    Entrez <- read.table("Entrez_length.txt",sep="\t",header=T)
    GenBank <- read.table("GenBank_length.txt",sep="\t",header=T)
    Ensemble <- read.table("Ensemble_length.txt",sep="\t",header=T)
    
    if(input$Term == "1")
      length.dat = Symbol
    if(input$Term == "2")
      length.dat = Entrez
    if(input$Term == "3")
      length.dat = GenBank
    if(input$Term == "4")
      length.dat = Ensemble
    
    colnames(RawInput)[1] = "GeneID"
    
    RawInfo = merge(length.dat, RawInput, by.x = "GeneID", by.y = "GeneID")
    convert = paste(input$Trans1,input$Trans2,sep="")
    
    effLen = RawInfo$length
    effLen[effLen > 400]  = effLen[effLen > 400] - 280 + 1
    
    if(convert == "13")
      CEXP = apply(RawInfo[,-c(1:2)], 2, countToTpm, effLen)
    if(convert == "12")
      CEXP = apply(RawInfo[,-c(1:2)], 2, countToFpkm, effLen)
    if(convert == "23")
      CEXP = apply(RawInfo[,-c(1:2)], 2, fpkmToTpm)
    
    CEXP.data = data.frame(RawInfo[,c(1:2)],CEXP)
    return(Data = CEXP.data)
  })

     
  output$table <- renderTable({
    head(datasetInput(),7)
  })
  
  output$downloadData <- downloadHandler(
    filename = function() { 
      paste('Coverted_',input$file1$name, '.csv', sep='') 
    },
    content = function(file) {
      write.csv(datasetInput(), file, row.names = F, quote=F)
    }
  )
  output$boxplot <- renderPlot({
    inFile <- input$file1
    if (is.null(inFile))
      return(NULL)
    
    box.dat = datasetInput()
    boxplot(log2(box.dat[,-c(1:2)]+1),las=2,main="Boxplot of log2(Expression)",ylab = "log2(Expression)")
  })
  
})
