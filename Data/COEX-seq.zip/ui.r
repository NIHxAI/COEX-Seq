library(shiny)
#library(ggplot2)

shinyUI(fluidPage(
  titlePanel("COEX-seq: COnvert a variety of measurements of gene EXpression in RNA-seq"),
  sidebarLayout(
    sidebarPanel(

      selectInput('Trans1', 'Before Measurement:', 
                  choices = list("Count" = 1, "FPKM" = 2, "TPM" = 3),
                  selected = 1),
      
      selectInput('Trans2', 'After Measurement:', 
                  choices = list("Count" = 1, "FPKM" = 2, "TPM" = 3),
                  selected = 3),
      
      radioButtons('Term', 'Gene Identifier:',
                   choices = list("Gene Symbol" = 1, "Entrez Gene" = 2,
                    "GenBank_Accession" = 3, "Ensemble" = 4), 
                   selected = 1),
      
      tags$hr(),
    
      
      fileInput('file1', 'Choose Input File',
                accept=c('text/csv', 
                         'text/comma-separated-values,text/plain', 
                         '.csv','.txt')),
      checkboxInput('header', 'Header', TRUE),
      radioButtons('sep', 'Separator',
                   c(Tab='\t',
                     Comma=',',
                     Semicolon=';'),
                   '\t'),
     
      tags$hr(),

      downloadButton('downloadData', 'Download')
     ),
      mainPanel(
        h4("Coverted Expression"),
        tableOutput('table'),
        h4("Boxplot of Coverted Expression"),
        plotOutput('boxplot')
      )
  )
))
